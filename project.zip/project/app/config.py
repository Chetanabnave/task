class Config:
    SECRET_KEY = 'secret-key'
    KEYCLOAK_SERVER_URL = 'http://your-keycloak-server/auth'
    KEYCLOAK_REALM = 'master'
    KEYCLOAK_CLIENT_ID = 'my_client'
    KEYCLOAK_CLIENT_SECRET = 'client-secret'
    STRIPE_API_KEY = 'stripe-api-key'
    DATABASE_URI = 'sqlite:///app.db'
