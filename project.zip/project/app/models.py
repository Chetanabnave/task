from flask_sqlalchemy import SQLAlchemy

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    user_id = Column(String(100), nullable=False)
    description = Column(String(50), nullable=False)
    time = Column(DateTime, default=datetime.datetime.utcnow)
    img_url = Column(String(100), unique=True, nullable=False)
